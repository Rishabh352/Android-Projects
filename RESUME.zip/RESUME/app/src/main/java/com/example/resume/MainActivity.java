package com.example.resume;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<String> resume = new ArrayList<>();
        resume.add("Name:-   RISHABH LINGSUGUR");
        resume.add("Email id:- \n" + "rishabh.sudarshanraj2020@vitbhopal.ac.in");
        resume.add("University:- VIT Bhopal");
        resume.add("Branch:- Computer Science and Engineering");
        resume.add("CGPA:- 8.0");
        resume.add("Strengths:-  Self confidence,good communication skills");
        resume.add("Hobbies:-  playing football,coding and playing cricket");
        resume.add("Skill:-  C/C++, java, python,android");
        resume.add("Experience:-  web developer");


    }
}